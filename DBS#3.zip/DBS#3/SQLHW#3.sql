#entity tables
CREATE TABLE User (
    UserName VARCHAR(50),
  	Type VARCHAR(50) NOT NULL,
  	Password VARCHAR(50) NOT NULL UNIQUE,
    LastName varchar(50) NOT NULL,
    FirstName varchar(50) NOT NULL,
  	Email VARCHAR(50) NOT NULL UNIQUE,
    Address varchar(255) NOT NULL,
  	PRIMARY KEY (UserName)
);

CREATE TABLE Payment (
  	PaymentID INT,
    LastName varchar(50) NOT NULL,
    FirstName varchar(50) NOT NULL,
  	Email VARCHAR(50) NOT NULL,
    Address varchar(255) NOT NULL,
  	Payment FLOAT NOT NULL,
  	PRIMARY KEY (PaymentID)
);

CREATE TABLE Computer (
  	ComputerID INT,
  	ComputerName VARCHAR(50) NOT NULL,
  	ComputerDescr VARCHAR(200) NOT NULL,
    RAM VARCHAR(10) NOT NULL,
  	ComputerPhoto BLOB NOT NULL,
  	ComputerPrice FLOAT NOT NULL,
  	ComputerBrand VARCHAR(50) NOT NULL,
  	PRIMARY KEY (ComputerID)
);

CREATE TABLE Orderr (
  	OrderID INT,
  	UserName VARCHAR(50) NOT NULL UNIQUE,
  	ComputerID INT NOT NULL UNIQUE,
  	ShipDate DATE NOT NULL,
  	LastName varchar(50) NOT NULL,
    FirstName varchar(50) NOT NULL,
  	Email VARCHAR(50) NOT NULL UNIQUE,
    Address varchar(255) NOT NULL,
  	PRIMARY KEY (OrderID)
);

CREATE TABLE Reviews (
  	ReviewID INT,
  	ReviewComment VARCHAR(150),
  	ReviewStars INT NOT NULL,
  	ReviewDate DATE NOT NULL,
  	PRIMARY KEY (ReviewID)
);

CREATE TABLE Cart (
  	CartID INT,
  	NumOfProducts INT NOT NULL,
  	TotalCost FLOAT NOT NULL,
  	PRIMARY KEY (CartID)
);

#relationship tables
CREATE TABLE Makesan (
  	UserName VARCHAR(50),
	OrderID INT,
	PRIMARY KEY (UserName, OrderID),
  	FOREIGN KEY (UserName) REFERENCES User,
  	FOREIGN KEY (OrderID) REFERENCES Orderr
);

  
CREATE TABLE AddsTo (
  	UserName VARCHAR(50),
  	CartID INT,
  	PRIMARY KEY (UserName, CartID),
  	FOREIGN KEY (UserName) REFERENCES User,
  	FOREIGN KEY (CartID) REFERENCES Cart
);

CREATE TABLE Confirms (
  	PaymentID INT,
  	OderID INT,
  	PRIMARY KEY (PaymentID, OrderID),
  	Foreign Key (PaymentID) REFERENCES Payment,
  	FOREIGN KEY (OrderID) REFERENCES Orderr
);

CREATE TABLE ShippedTo (
  	ComputerID INT,
  	UserName VARCHAR(50),
  	PRIMARY KEY (ComputerID, UserName),
  	Foreign KEY (ComputerID) REFERENCES Computer,
  	FOREIGN KEY (UserName) REFERENCES User
);

CREATE TABLE Makes (
  	UserName VARCHAR(50),
  	ReviewID INT,
  	PRIMARY KEY (UserName, ReviewID),
  	FOREIGN KEY (Username) REFERENCES User,
  	FOREIGN KEY (ReviewID) REFERENCES Reviews
);

#ISA Hierarchies
#User ISA's
CREATE TABLE UserFree (
  	UserName VARCHAR(50),
  	CanBuy TINYINT,
  	PRIMARY KEY (UserName),
  	FOREIGN KEY (UserName) REFERENCES User
);
 
CREATE TABLE UserPremium (
  	UserName VARCHAR(50),
  	CanBuy TINYINT,
  	FastShipping TINYINT,
  	CouponCode INT,
  	PRIMARY KEY (UserName),
  	FOREIGN KEY (UserName) REFERENCES User
);

#Computer ISA's
CREATE TABLE ComputerDesktop (
  	ComputerID INT,
  	KeyboardSize INT NOT NULL,
  	MonitorSize INt NOT NULL,
  	MouseSize INT NOT NULL,
  	Processor VARCHAR(10) NOT NULL,
  	GraphicsCard TINYint,
  	PRIMARY KEY (ComputerID),
  	FOREIGN KEY (ComputerID) REFERENCES Computer
);

CREATE TABLE ComputerLaptop (
  	ComputerID INT,
  	OperatingSystem VARCHAR(50) NOT NULL,
  	Weight FLOAT NOT NULL,
  	Processor VARCHAR(10) NOT NULL,
  	Display Varchar(50) NOT NULL,
  	PRIMARY KEY (ComputerID),
  	FOREIGN KEY (ComputerID) REFERENCES Computer
);

CREATE TABLE ComputerGamLaptop (
  	ComputerID INT,
  	OperatingSystem VARCHAR(50) NOT NULL,
  	Processor VARCHAR(10) NOT NULL,
  	Display Varchar(50) NOT NULL,
  	GraphicsCard TINYINT,
  	CPUCore Varchar(20) NOT NULL,
  	PRIMARY KEY (ComputerID),
  	FOREIGN KEY (ComputerID) REFERENCES Computer
);

#Payment ISA's
CREATE TABLE PaymentPaypal (
  	PaymentID INT,
  	PPusername Varchar(50) NOT NULL Unique,
  	PPpassword Varchar(50) NOT NULL UNIQUE,
  	PRIMARY KEY (PaymentID),
  	FOREIGN KEY (PaymentID) REFERENCES Payment
);

CREATE TABLE PaymentBank (
  	PaymentID INT,
  	Iban VARCHAR(50) NOT NULL UNIQUE,
  	PRIMARY KEY (PaymentID),
  	FOREIGN KEY (PaymentID) REFERENCES Payment
);

CREATE TABLE PaymentCard (
  	PaymentID INT,
  	CardNumber VARCHAR(50) NOT NULL UNIQUE,
  	Ccv INT NOT NULL,
  	ExpirationDate DATE NOT NULL,
  	PRIMARY KEY (PaymentID),
  	FOREIGN KEY (PaymentID) REFERENCES Payment
);



