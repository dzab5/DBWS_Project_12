<html>


<link href="product_page.css" rel="stylesheet" type="text/css" />
<title> LAPTIC</title>

<body>
<div class="header">
    
    <h3> <img src="photos/laptic%20logo1.png" alt="logo"/> Top yourself with the perfect choice for you
    <div class = "header-right">
    
        <a href="Home.html">Home</a>
        <a class="active" href="sign_in.html">Log In</a>
        <a href="about.html">About Us</a>
        <a href="imprint.html">Imprint</a>
        
    </div>
    </h3>
</div>

<div class="responsive">
    <div class="product">
      <a target="_blank" href="photos/laptop%201.jpg">
        <img class = "pic" src="photos/laptop%201.jpg" alt="Laptop">
      </a>
      <div class="desc"> Dell XPS 13: notebook with 13.4 inch display <br>, Core ™ i7 processor, 1
      6 GB RAM, 512 GB SSD, <br> Intel Iris Plus graphics, platinum silver / 
      black <br> 1400€ <br><br><br><br><br><br><br><br><br></div>
    </div>
</div>  
<div class="wrapper">
    <a class="button" href="Laptop.html"  >buy now</a>
    <a class="button" href="gaming.html" >add to cart</a>

</div>

<span>User Ratings</span>

<span class="fa fa-star"></span>
<p>4.1 average based on 254 reviews.</p>
<hr style="border:3px solid #f1f1f1">

<div class="row">
  <div class="side">
    <div>5 star</div>
  </div>
  <div class="middle">
    <div class="bar-container">
      <div class="bar-5"></div>
    </div>
  </div>
  <div class="side right">
    <div>150</div>
  </div>
  <div class="side">
    <div>4 star</div>
  </div>
  <div class="middle">
    <div class="bar-container">
      <div class="bar-4"></div>
    </div>
  </div>
  <div class="side right">
    <div>63</div>
  </div>
  <div class="side">
    <div>3 star</div>
  </div>
  <div class="middle">
    <div class="bar-container">
      <div class="bar-3"></div>
    </div>
  </div>
  <div class="side right">
    <div>15</div>
  </div>
  <div class="side">
    <div>2 star</div>
  </div>
  <div class="middle">
    <div class="bar-container">
      <div class="bar-2"></div>
    </div>
  </div>
  <div class="side right">
    <div>6</div>
  </div>
  <div class="side">
    <div>1 star</div>
  </div>
  <div class="middle">
    <div class="bar-container">
      <div class="bar-1"></div>
    </div>
  </div>
  <div class="side right">
    <div>20</div>
  </div>
</div>

</body>
</html>
  
